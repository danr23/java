import javax.swing.*;
import java.awt.*;
import javax.swing.text.*;

class Gui {
	public static void main(String[] args)
	{
		
		JFrame frame = new JFrame("Standart model of elementary Particles!!");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setSize(600, 600);
		
		JPanel panel = new JPanel();
		
		JButton button1 = new JButton(new ImageIcon(Gui.class.getResource("/buttons/photo/particles.jpg")));
		JButton button2 = new JButton(new ImageIcon(Gui.class.getResource("/buttons/photo/welcome.jpg")));
		JButton button3 = new JButton(new ImageIcon(Gui.class.getResource("/buttons/photo/welcome.jpg")));
		JButton button4 = new JButton(new ImageIcon(Gui.class.getResource("/buttons/photo/particles.jpg")));
		
		JButton particles = new JButton("Welcome! This is Standart model of elementary particles!!");
		
		JButton particles2 = new JButton("Welcome! This is Standart model of elementary particles!!");
		
		panel.add(button2);
		panel.add(button3);
		panel.add(button1);
		panel.add(button4);
		panel.add(particles2);
		
		frame.add(BorderLayout.CENTER, panel);
		
		frame.setVisible(true);
		
	}
}
