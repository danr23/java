import javax.swing.*;
import java.awt.*;

class Gui {
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Elementary Particles!!");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setSize(600, 600);
		
		JButton button1 = new JButton(new ImageIcon("particles.jpg"));
		JButton button2 = new JButton(new ImageIcon("welcome.jpg"));
		JTextArea particles = new JTextArea("This is Elementary particles!!");
		
		frame.getContentPane().add(BorderLayout.SOUTH, button1);
		frame.getContentPane().add(BorderLayout.NORTH, button2);
		frame.add(BorderLayout.CENTER, particles);
		
		frame.setVisible(true);
		
	}
}
